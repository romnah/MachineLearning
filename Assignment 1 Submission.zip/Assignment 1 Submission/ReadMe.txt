Name: Romit Nahar
Email: rn436@drexel.edu

The files are being coded in Matlab.
To run, just the location of yalefaces folder is to be changed.

ZIP Conatins:
1. PDF for theory questions and images of the results
2. PCA.m - Code for Q.2
3. EigenFaces.m - Code for Q.3
4. kmeans.m - Code for Q.4
5. K_2.avi - Video file for kmeans

Thank You!